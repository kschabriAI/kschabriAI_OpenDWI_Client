use domain::{CompletionRequest, CompletionResponse, PaginatedResponse, SearchResponse, WorkInstruction, DomainError};
use reqwest::Client;

#[cfg(feature = "jni")]
use robusta_jni::bridge;
#[cfg(feature = "jni")]
use once_cell::sync::Lazy;
#[cfg(feature = "jni")]
use tokio::runtime::Runtime;

#[cfg(feature = "jni")]
static RUNTIME: Lazy<Runtime> = Lazy::new(|| Runtime::new().expect("Failed to create Tokio Runtime"));

#[derive(Clone)]
pub struct InstructionClient {
    client: Client,
    base_url: String,
}

impl InstructionClient {
    pub fn new(base_url: &str) -> Self {
        Self {
            client: Client::new(),
            base_url: base_url.trim_end_matches('/').to_string(), // Sanitize base URL
        }
    }

    pub async fn get_instructions(&self, query: &[(&str, &str)]) -> Result<PaginatedResponse<WorkInstruction>, DomainError> {
        let url = format!("{}/instructions", self.base_url);
        let res = self.client
            .get(url)
            .query(query)
            .send()
            .await
            .map_err(|e| DomainError::Internal { message: e.to_string() })?;
            
        let text = res.text().await.map_err(|e| DomainError::Internal { message: e.to_string() })?;
        if text.trim().is_empty() {
            return Err(DomainError::Internal { message: "Empty response body".into() });
        }

        serde_json::from_str(&text).map_err(|e| DomainError::Internal { message: e.to_string() })
    }
	
    pub async fn search_instructions(&self, query_text: &str) -> Result<SearchResponse, DomainError> {
        let url = format!("{}/instructions", self.base_url);
        let res = self.client
            .get(url)
            .query(&[("q", query_text)])
            .send()
            .await
            .map_err(|e| DomainError::Internal { message: e.to_string() })?;

        let text = res.text().await.map_err(|e| DomainError::Internal { message: e.to_string() })?;
        serde_json::from_str(&text).map_err(|e| DomainError::Internal { message: e.to_string() })
    }

    pub async fn get_by_id(&self, id: &str) -> Result<WorkInstruction, DomainError> {
        let url = format!("{}/instructions/{}", self.base_url, id);
        let res = self.client
            .get(url)
            .send()
            .await
            .map_err(|e| DomainError::Internal { message: e.to_string() })?;

        let text = res.text().await.map_err(|e| DomainError::Internal { message: e.to_string() })?;
        serde_json::from_str(&text).map_err(|e| DomainError::Internal { message: e.to_string() })
    }
	
    pub async fn complete_step(&self, payload: &CompletionRequest) -> Result<CompletionResponse, DomainError> {
		let url = format!("{}/instructions/complete", self.base_url);
		
		let response = self.client
			.post(url)
			.json(payload)
			.send()
			.await
			.map_err(|e| DomainError::Internal { message: format!("Network Error: {}", e) })?;

		let status_code = response.status();
		let text = response.text().await.map_err(|e| DomainError::Internal { message: e.to_string() })?;
		
		match serde_json::from_str::<CompletionResponse>(&text) {
			Ok(parsed) => Ok(parsed),
			Err(e) => {
				Err(DomainError::Internal {
					message: format!("Decoding Error! Status: {}. Error: {}. Raw Body: '{}'", status_code, e, text)
				})
			}
		}
	}
}

// --- RobustaJNI Bridge ---
#[cfg(feature = "jni")]
#[bridge]
pub mod jni_api {
    use super::{InstructionClient, RUNTIME};
    use robusta_jni::convert::{Signature, IntoJava, FromJava};

    #[package(org.kschbaridwi.client)] // Ensure this matches your Kotlin package
    pub struct NativeClient;

    impl NativeClient {
        pub fn fetch_instructions_sync(base_url: String) -> String {
            RUNTIME.block_on(async {
                let client = InstructionClient::new(&base_url);
                match client.get_instructions(&[]).await {
                    Ok(data) => serde_json::to_string(&data).unwrap(),
                    Err(e) => format!("{{\"error\": \"{}\"}}", e),
                }
            })
        }

        pub fn complete_step_sync(base_url: String, payload_json: String) -> String {
            RUNTIME.block_on(async {
                let client = InstructionClient::new(&base_url);
                match serde_json::from_str(&payload_json) {
                    Ok(payload) => match client.complete_step(&payload).await {
                        Ok(res) => serde_json::to_string(&res).unwrap(),
                        Err(e) => format!("{{\"error\": \"{}\"}}", e),
                    },
                    Err(e) => format!("{{\"error\": \"Invalid JSON: {}\"}}", e),
                }
            })
        }
    }
}