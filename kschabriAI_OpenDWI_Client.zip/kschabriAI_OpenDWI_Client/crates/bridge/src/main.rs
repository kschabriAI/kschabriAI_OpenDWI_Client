use bridge::InstructionClient;
use anyhow::Result;
use serde::Deserialize;
use serde_json::json;

const API_BASE_URL: &str = "http://localhost:9000";

// A simple local struct to deserialize responses if needed outside the main client struct
#[derive(Deserialize, Debug)]
struct SimpleApiResponse {
    status: String,
    message: Option<String>,
}

async fn post_test_case(test_name: &str, payload: serde_json::Value) -> Result<()> {
    println!("\n{}", test_name);
    let client = reqwest::Client::new();
    let response = client
        .post(&format!("{}/instructions/complete", API_BASE_URL))
        .json(&payload)
        .send()
        .await?;

    let text = response.text().await?;
    
    match serde_json::from_str::<SimpleApiResponse>(&text) {
        Ok(res) => {
            let display_msg = res.message.unwrap_or_else(|| "No additional message".to_string());
            println!("API Response -> Status: {}, Message: {}", res.status, display_msg);
        },
        Err(e) => {
            eprintln!("Failed to parse JSON: {}", e);
            eprintln!("Raw response text: {}", text);
        }
    }
    Ok(())
}


// --- Main Execution ---

#[tokio::main]
async fn main() -> Result<()> {
    let client = InstructionClient::new(API_BASE_URL);
	
    println!("=== FETCH TEST CASES ===");

    // 1. All Instructions
    println!("\n1. Fetch All:");
    let res1 = client.get_instructions(&[]).await?;
    println!(" - Count: {}", res1.data.len());

    // 2. Page 2
    println!("\n2. Fetch Page 2:");
    let res2 = client.get_instructions(&[("page", "2")]).await?;
    println!(" - Current Page: {}", res2.metadata.current_page);

    // 3. Single Instruction WI-007
    println!("\n3. Fetch WI-007:");
    let res3 = client.get_by_id("WI-007").await?;
    println!(" - ID: {}, Version: {}", res3.id.0, res3.version);

    // 4. Evidence Required
    println!("\n4. Filter Evidence=true:");
    let res4 = client.get_instructions(&[("evidence", "true")]).await?;
    println!(" - Found: {} items", res4.data.len());

    // 5. Evidence Required + Page 2
    println!("\n5. Filter Evidence=true & Page 2:");
    let res5 = client.get_instructions(&[("evidence", "true"), ("page", "2")]).await?;
    println!(" - Page: {}", res5.metadata.current_page);

    // 6. Single Tool Filter
    println!("\n6. Filter Tool=LV-02:");
    let res6 = client.get_instructions(&[("tool", "LV-02")]).await?;
    println!(" - Found: {} items", res6.data.len());

    // 7. Multiple Tool Filter (Duplicate Keys)
    println!("\n7. Filter Tool=LV-02 & Tool=MT-09:");
    let res7 = client.get_instructions(&[("tool", "LV-02"), ("tool", "MT-09")]).await?;
    println!(" - Found: {} items", res7.data.len());

    // 8. Search Query: align
    println!("\n8. Search 'align':");
    let res8 = client.search_instructions("align").await?;
    for item in res8.results {
        println!(" - Match: {} (Seq: {})", item.instruction_id, item.step_sequence);
    }

    // 9. Search Query: Verify
    println!("\n9. Search 'Verify':");
    let res9 = client.search_instructions("Verify").await?;
    for item in res9.results {
        println!(" - Match: {} (Seq: {})", item.instruction_id, item.step_sequence);
    }

    println!("\n=== POST TEST CASES ===");
	
    // 1. Numeric Success (WI-002, Step 201, 5.0Nm, no media)
    post_test_case(
        "1. Numeric Success (WI-002, 5.0 Nm)",
        json!({"instruction_id":"WI-002","step_sequence":201,"num_val":5.0,"has_media":false})
    ).await?;

    // 2. Numeric Fail (Out of Range: 10.0Nm)
    post_test_case(
        "2. Numeric Fail (Out of Range: 10.0 Nm)",
        json!({"instruction_id":"WI-002","step_sequence":201,"num_val":10.0,"has_media":false})
    ).await?;

    // 3. Numeric Fail (Missing Value)
    post_test_case(
        "3. Numeric Fail (Missing num_val)",
        json!({"instruction_id":"WI-002","step_sequence":201,"has_media":false})
    ).await?;
    
    // 4. Boolean Success (WI-001, has_media: true)
    post_test_case(
        "4. Boolean Success (WI-001, has_media: true)",
        json!({"instruction_id":"WI-001","step_sequence":101,"bool_val":true,"has_media":true})
    ).await?;

    // 5. Boolean Fail (Missing Value)
    post_test_case(
        "5. Boolean Fail (Missing bool_val)",
        json!({"instruction_id":"WI-001","step_sequence":101,"has_media":true})
    ).await?;

    // 6. Boolean Fail (Missing Evidence) - assuming WI-001 requires evidence
    post_test_case(
        "6. Boolean Fail (Missing Evidence)",
        json!({"instruction_id":"WI-001","step_sequence":101,"bool_val":true,"has_media":false})
    ).await?;

    // 7. Boolean Success (WI-007, Step 702, has_media: true)
    post_test_case(
        "7. Boolean Success (WI-007, has_media: true)",
        json!({"instruction_id":"WI-007","step_sequence":702,"bool_val":true,"has_media":true})
    ).await?;

    // 8. Boolean Fail (WI-007, Missing Evidence)
    post_test_case(
        "8. Boolean Fail (WI-007, Missing Evidence)",
        json!({"instruction_id":"WI-007","step_sequence":702,"bool_val":true,"has_media":false})
    ).await?;

    // 9. Boolean Fail (WI-007, Missing Value)
    post_test_case(
        "9. Boolean Fail (WI-007, Missing bool_val)",
        json!({"instruction_id":"WI-007","step_sequence":702,"has_media":true})
    ).await?;

    Ok(())
}