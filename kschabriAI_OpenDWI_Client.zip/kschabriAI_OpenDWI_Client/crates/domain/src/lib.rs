#[cfg(feature = "uniffi")]
uniffi::setup_scaffolding!();

use serde::{Deserialize, Serialize};
#[cfg(feature = "wasm")]
use wasm_bindgen::prelude::wasm_bindgen;

// Pure Rust Error: No uniffi::Error here
#[derive(Debug, thiserror::Error)]
pub enum DomainError {
    #[error("Internal Domain Error: {message}")]
    Internal { message: String },
}

#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct WorkInstructionId(pub String);

#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ToolId(pub String);

#[cfg(feature = "uniffi")]
uniffi::custom_newtype!(WorkInstructionId, String);
#[cfg(feature = "uniffi")]
uniffi::custom_newtype!(ToolId, String);

#[cfg_attr(feature = "uniffi", derive(uniffi::Enum))]
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum StepInput {
    Checkbox { label: String },
    Numeric { unit: String, min: f64, max: f64 },
    Text { prompt: String },
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Step {
    pub sequence: u32,
    pub instruction_text: String,
    pub media_url: Option<String>,
    #[cfg_attr(feature = "wasm", wasm_bindgen(skip))]
    pub input_config: Option<StepInput>,
    pub evidence_required: bool,
}

#[cfg(feature = "wasm")]
#[wasm_bindgen]
impl Step {
    #[wasm_bindgen(getter)]
    pub fn input_config_js(&self) -> wasm_bindgen::JsValue {
        serde_wasm_bindgen::to_value(&self.input_config)
            .unwrap_or(wasm_bindgen::JsValue::NULL)
    }
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkInstruction {
    pub id: WorkInstructionId,
    pub version_tag: u32,
    pub version: String,
    pub tools_required: Vec<ToolId>,
    pub steps: Vec<Step>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PaginatedResponse<T> {
    pub data: Vec<T>,
    pub metadata: PaginationMetadata,
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PaginationMetadata {
    pub current_page: u32,
    pub total_pages: u32,
    pub total_items: u32,
    pub next_page: Option<u32>,
    pub prev_page: Option<u32>,
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Serialize, Deserialize, Clone)] 
pub struct MatchedStepProjection {
    pub instruction_id: String,
    pub step_sequence: u32,
    pub instruction_text: String,
    pub evidence_required: bool,
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct SearchResponse {
    pub mode: String,
    pub results: Vec<MatchedStepProjection>,
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompletionRequest {
    pub instruction_id: String,
    pub step_sequence: u32,
    pub has_media: bool,
    pub num_val: Option<f64>,
    pub bool_val: Option<bool>,
    pub text_val: Option<String>,
}

#[cfg_attr(feature = "uniffi", derive(uniffi::Record))]
#[cfg_attr(feature = "wasm", wasm_bindgen(getter_with_clone))]
#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct CompletionResponse {
    pub status: String,
    #[serde(alias = "error")]
    pub message: Option<String>, 
}